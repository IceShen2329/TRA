package gui.sample;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Transaction {
    public double balance = 5000;
    private double withdraw = 0;
    private double deposit = 0;
    
    Scanner scan = new Scanner(System.in);
    
    DecimalFormat moneyFormat = new DecimalFormat("'P'###,##0.00");
    
    public Transaction(){
    }
    public Transaction(double balance, double withdraw, double deposit){
        this.balance = balance;
        this.withdraw = withdraw;
        this.deposit = deposit;
    }
    public double getBalance(){
        return balance; 
    }
    //checking the balance
    public double getWithdrawBalance(){
        return withdraw;
    }
    
    //withdraw saving
    public double calcuWithdrawBalance(double amount){
     withdraw = balance - amount;
        return withdraw;
    }
    public double getDepositBalance(){
        return deposit;
    }
    public double calcuDepositBalance(double amount){
        deposit = balance + amount;
        return deposit;
    }
    
    public void getWithdraw(){
    boolean end = false;
    
    
        while(!end){
            System.out.println("Your Balance is " + moneyFormat.format(balance));
            double Screen = scan.nextDouble();
            
            if(balance >= Screen){
            calcuWithdrawBalance(Screen);
            end = true;
            Ended FB= new Ended();
            }
                else{
                System.out.println("You don't have enough balance");
            }
        }
    }
    public void getDeposit(){
        boolean end = false;
        while(!end){
            System.out.println("Your Balance is " + moneyFormat.format(balance));
            double amount = scan.nextDouble();
            calcuDepositBalance(amount);
            
            if(balance + amount> 0 && amount > 0){
            System.out.println("Your Balance is " + moneyFormat.format(deposit));
            end = true;
            }
                else{
                System.out.println("You don't have enough balance");
            }
        }
    }
    
}
